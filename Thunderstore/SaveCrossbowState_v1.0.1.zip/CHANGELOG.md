| `Version` | `Update Notes`                                                            |
|-----------|---------------------------------------------------------------------------|
| 1.0.1     | - Now save Dundr state. (Bascially a magic crossbow, so people wanted it) |
| 1.0.0     | - Initial Release                                                         |